package com.untd.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.untd.User;

@Controller
@Scope("session")


public class LoginController {
@RequestMapping(value="/login",method = RequestMethod.GET, produces = "application/json",params = {"username","password"})

public @ResponseBody ()
String getUser(@RequestParam(value = "username") String username,  @RequestParam(value = "password") String password ,HttpServletRequest request) {
   
	String uname= "naresh";
	String psword="addanki";
	if (username.equals(uname) && password.equals(psword) ){
		System.out.println("User logged in succesfully");
	 request.getSession().setAttribute("login" ,"success");
	return "Success";
}
else{
	System.out.println("Invalid username and password recieved");
    return "Username or password are incorrect";
   
 }
}

@RequestMapping(value="/logout")

public @ResponseBody ()
String clearSession(HttpServletRequest request, HttpSession session) {
     
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
	 request.getSession().invalidate();
	 System.out.println("User loggedout successfully ");
	 return "Logout";	
    }
	else{
		System.out.println("User not logged in but tried logout");
		return "not loggedin";
	}
}


@RequestMapping(value="/checkLogin",produces = "application/json")
public @ResponseBody () 
String checkLogin ( HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
                	return "Success";	
        	 }
	 else {
				
		 return "Fail";
	 	}
}



}
