package com.untd;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class HistoryMapper implements RowMapper {
	   public History mapRow(ResultSet rs, int rowNum) throws SQLException {
	      History history = new History();
	      history.setUser(rs.getString("user"));
	      history.setCpu(rs.getString("cpu"));
	      history.setLaptop(rs.getString("laptop"));
	      history.setServer(rs.getString("server"));
	      history.setMonitor(rs.getString("monitor"));
	      history.setPhone(rs.getString("phone"));
	      history.setCard(rs.getString("card"));
	      history.setHeadset(rs.getString("headset"));
	      
	      history.setWebcam(rs.getString("webcam")); 
	      history.setHdd(rs.getString("hdd")); 
	      history.setTape(rs.getString("tape")); 
	      history.setRam(rs.getString("ram")); 
	      history.setToner(rs.getString("toner")); 
	      history.setExt(rs.getString("ext")); 
	      history.setLicense(rs.getString("license"));
	      history.setModem(rs.getString("modem")); 
	      history.setUid(rs.getString("uid"));
	      history.setSrc(rs.getString("src"));
	      history.setDest(rs.getString("dest")); 
	      history.setTic(rs.getString("tic"));
	      history.setUdate(rs.getString("udate")); 
	      history.setInfo(rs.getString("info"));
	      history.setComm(rs.getString("comm"));
	      
	      
	      
	      return history;
	   }
	}