﻿'use strict';

// optional controllers

   function LoginCheckCtrl ($scope,$http,$window){
	   $http.get('http://localhost:8080/AssetTool/api/checkLogin')
	   .success(function (response) {  
            $scope.value = response; 
                if ($scope.value == "Success") {    
                $window.location.href = 'home';
            }
            else{
            	
            	$window.location.href = "";
            	
            }
	   });
   }
   
	

function LoginCtrl ($scope,$http,$window){
	$scope.SendData = function (Data) {  
        
		
		var userName = Data.userName;  
       var password = Data.password; 
		
		var input = "username=" + userName + "&password=" + password;
		       
		$http.get('http://localhost:8080/AssetTool/api/login?'+input)
		.success(function (response) {  
            $scope.value = response; 
            if ($scope.value == "Success") {    
                $window.location.href = 'home';
            }
            else{
            	alert('invalid credentials');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
  
}

function LogoutCtrl($scope,$http,$window){
		$http.get('http://localhost:8080/AssetTool/api/logout')
			.success(function (response) { 
				$scope.value = response; 
	            if ($scope.value == "Logout") {  
	            	
	                $window.location.href = '';
	            }
	            else if($scope.value == "not loggedin"){
	            	alert("Not logged in");
	            	$window.location.href = '';
	            }
			}).
			error(function (error) {  
	              alert(error);  
	           });
}


function CpuDetailCtrl ($scope,$http,$window){
	        
		$http.get('http://localhost:8080/AssetTool/api/cpuStores')
		.success(function (response) {  
            $scope.html = response; 
             
                     })  
           .error(function (error) {  
              alert(error);  
           });  
    }  



function CpuAddCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var DIMM = $routeParams.DIMM;  
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var br = $routeParams.br;  
	var flr = $routeParams.flr;
	var loc = $routeParams.loc;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram + "&DIMM=" + DIMM + 
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 + "&br=" + br + 
	"&flr=" + flr + "&loc=" + loc + "&ea=" + ea ;
	  
		
		$http.get('http://localhost:8080/AssetTool/api/cpuAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
            
            if ($scope.value == "success") {    
            	alert("Cpu Added succesfully")
                $window.location.href = 'getCpuBySno?sno='+sno;
            }
            
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert("Unable to Add the CPU: Duplicate records found or Invalid input");
            	$window.location.href = 'cpuAddHome';
            }
         })  
           .error(function (error) {  
        	   alert("Unable to Add the CPU: Duplicate records found or Invalid input");
        	   $window.location.href = 'cpuAddHome';
           });  
    }  


function CpuAddHomeCtrl ($scope,$http,$window){
	
	$http.get('http://localhost:8080/AssetTool/api/cpuAddHome')
	.success(function (response) {  
        $scope.html = response; 
         
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  
	

function CpuUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/cpuUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetCpuBySnoCtrl ($scope,$http,$window,$routeParams,$location){
	var sno = $routeParams.sno;
	
	$http.get('http://localhost:8080/AssetTool/api/getCpuDetails?sno='+sno)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}

function CpuUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var DIMM = $routeParams.DIMM;  
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var br = $routeParams.br;  
	var flr = $routeParams.flr;
	var loc = $routeParams.loc;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram + "&DIMM=" + DIMM + 
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 + "&br=" + br + 
	"&flr=" + flr + "&loc=" + loc + "&ea=" + ea ;
	  
	  
	   $http.get('http://localhost:8080/AssetTool/api/cpuUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getCpuBySno?sno='+sno;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             
         
	   })             
    .error(function (error) {  
    	alert('Unable to Update Details: Duplicate records found Or Invalid Input');
   	 $window.location.href = 'getCpuBySno?sno='+sno;
    }); 
}

function CpuStoreCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/cpuStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function CpuDesktopCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/cpuDesktop')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  



function CpuOutCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/cpuOut')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  
function CpuReportCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/cpuReport')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function FinalCpuReportCtrl ($scope,$http,$window,$routeParams){
	var sno = $routeParams.sno;
	var reportType = $routeParams.reportType;
	
	if(reportType == "current") {
		$http.get('http://localhost:8080/AssetTool/api/getCpuReport?sno='+sno)
			.success(function (response) {  
				$scope.html = response; 
            	})  
            .error(function (error) {  
            	alert(error);  
       }); 
	}
	
	if(reportType == "history"){
		 
		$http.get('http://localhost:8080/AssetTool/api/getCpuHistoryReport?sno='+sno)
		.success(function (response) {  
			$scope.html = response; 
        	})  
        .error(function (error) {  
        	alert(error);  
   }); 
}
}


/// User details ///

function UserDetailCtrl ($scope,$http,$window){
	
	     
		$http.get('http://localhost:8080/AssetTool/api/userDetails')
		.success(function (response) {  
			
            $scope.html = response; 
                       
                     })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
// User update //

function UserUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/userUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetUserByUIDCtrl ($scope,$http,$window,$routeParams,$location){
		var uid = $routeParams.uid
		
		$http.get('http://localhost:8080/AssetTool/api/getUserDetails?uid='+uid)
			.success(function (response) {
		        $scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       });  
}

function UserUpdateCtrl ($scope,$http,$window,$routeParams){
	   var id    = $routeParams.id;  
       var fname = $routeParams.fname; 
	   var lname = $routeParams.lname;
	   var uid   = $routeParams.uid;
	   var team  = $routeParams.team;
	   var role  = $routeParams.role;
	   var stat  = $routeParams.stat;
	   var cube  = $routeParams.cube;
	   var jdate = $routeParams.jdate;
	   var edate = $routeParams.edate;
	  
	   var input = "id=" + id + "&fname=" + fname + "&lname=" + lname + "&uid=" + uid + "&team=" + team + "&role=" + role + "&stat=" + stat + "&cube=" + cube + "&jdate=" + jdate+ "&edate=" + edate ;
	  
	   $http.get('http://localhost:8080/AssetTool/api/userUpdateFinal?'+input)
	   .success(function (response) {  
        		$scope.value = response; 
				if ($scope.value == "success") {    
                 	alert("Details Updated succesfully")
                    $window.location.href = 'getUserByUID?uid='+uid;
                }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
               
            
	   })             
       .error(function (error) {  
    	   alert('Duplicate records found Or Invalid input');
    	   $window.location.href = 'getUserByUID?uid='+uid;
       }); 
}

function UserAddCtrl ($scope,$http,$window){
	
	$scope.SendUser = function (Data) {  
		
		var id    = Data.id;  
        var fname = Data.fname; 
		var lname = Data.lname;
		var uid   = Data.uid;
		var team  = Data.team;
		var role  = Data.role;
		var stat  = Data.stat;
		var cube  = Data.cube;
		var jdate = Data.jdate;
		var edate = Data.edate;
		
		var input = "id=" + id + "&fname=" + fname + "&lname=" + lname + "&uid=" + uid + "&team=" + team + "&role=" + role + "&stat=" + stat + "&cube=" + cube + "&jdate=" + jdate+ "&edate=" + edate ;
		  
		$http.get('http://localhost:8080/AssetTool/api/userAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("user Added succesfully")
                $window.location.href = 'userDetails';
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert('Unable to update details: Duplicate records found Or Invalid input');
            }
         })  
           .error(function (error) {  
              alert(error);  
           });  
    }  
}

function UserReportCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/userReport')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function FinalUserReportCtrl ($scope,$http,$window,$routeParams){
	var uid = $routeParams.uid;
	
	
	
		$http.get('http://localhost:8080/AssetTool/api/getUserReport?uid='+uid)
			.success(function (response) {  
				$scope.html = response; 
            	})  
            .error(function (error) {  
            	alert(error);  
       }); 
	
}

/// Start of Monitor controllers  ///
function MonitorStoreCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorDesktopCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorDesktop')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorFaultyCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorFaulty')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorOutCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorOut')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/monitorAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorAddHomeCtrl ($scope,$http,$window){
	
	$http.get('http://localhost:8080/AssetTool/api/monitorAddHome')
	.success(function (response) {  
        $scope.html = response; 
         
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function MonitorAddCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
		  
		$http.get('http://localhost:8080/AssetTool/api/monitorAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("Monitor Added succesfully")
                $window.location.href = 'getMonitorBySno?sno='+sno;
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert('Unable to update details: Duplicate records found Or Invalid input');
            	$window.location.href = 'monitorAddHome';
            }
         })  
           .error(function (error) {  
        	   alert('Unable to update details: Duplicate records found Or Invalid input');
           	$window.location.href = 'monitorAddHome';
           });  
    }  


function MonitorUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/monitorUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetMonitorBySnoCtrl ($scope,$http,$window,$routeParams,$location){
	var sno = $routeParams.sno
	
	$http.get('http://localhost:8080/AssetTool/api/getMonitorDetails?sno='+sno)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function MonitorUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
	  
	  $http.get('http://localhost:8080/AssetTool/api/monitorUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getMonitorBySno?sno='+sno;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
            
         
	   })             
    .error(function (error) {  
    	alert('Unable to update the details: Duplicate records found Or Invalid input');
		$window.location.href = 'getMonitorBySno?sno='+sno;  
    }); 
}


function MonitorReportCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/monitorReport')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function FinalMonitorReportCtrl ($scope,$http,$window,$routeParams){
	var sno = $routeParams.sno;
	var reportType = $routeParams.reportType;
	
	if(reportType == "current") {
		$http.get('http://localhost:8080/AssetTool/api/getMonitorReport?sno='+sno)
			.success(function (response) {  
				$scope.html = response; 
            	})  
            .error(function (error) {  
            	alert(error);  
       }); 
	}
	if(reportType == "history"){
		 
		$http.get('http://localhost:8080/AssetTool/api/getMonitorHistoryReport?sno='+sno)
		.success(function (response) {  
			$scope.html = response; 
        	})  
        .error(function (error) {  
        	alert(error);  
   }); 
}
}
/// End of Monitor controllers ////

/// Start of Phone controllers ////
function PhoneStoreCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneDesktopCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneDesktop')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneFaultyCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneFaulty')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneOutCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneOut')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function PhoneAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/phoneAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  


function PhoneAddHomeCtrl ($scope,$http,$window){
	
	$http.get('http://localhost:8080/AssetTool/api/phoneAddHome')
	.success(function (response) {  
        $scope.html = response; 
         
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  
function PhoneAddCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
		  
		$http.get('http://localhost:8080/AssetTool/api/phoneAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
                    
            if ($scope.value == "success") {    
            	alert("Phone details Added succesfully")
                $window.location.href = 'getPhoneBySno?sno='+sno;
            }
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            
         })  
           .error(function (error) {  
        	   alert('Unable to update details: Duplicate records found Or Invalid input');
           	$window.location.href = 'phoneAddHome';
           });  
    }  


function PhoneUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/phoneUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetPhoneBySnoCtrl ($scope,$http,$window,$routeParams,$location){
	var sno = $routeParams.sno;
	
	$http.get('http://localhost:8080/AssetTool/api/getPhoneDetails?sno='+sno)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function PhoneUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id        = $routeParams.id;  
    var model     = $routeParams.model; 
	var vendor    = $routeParams.vendor;
	var sno	      = $routeParams.sno;
	var size  	  = $routeParams.size;
	var color     = $routeParams.color;
	var pdate     = $routeParams.pdate;
	var warranty  = $routeParams.warranty;
	var edate     = $routeParams.edate;
	var stat      = $routeParams.stat;
	var bond      = $routeParams.bond;
	var uid1      = $routeParams.uid1;
	var uid2      = $routeParams.uid2;
	var input = "id=" + id + "&model=" + model + "&vendor=" + vendor + "&sno=" + sno + "&size=" + size + "&color=" + color + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" + edate+ "&stat=" + stat+ "&bond=" + bond+ "&uid1=" + uid1+ "&uid2=" + uid2 ;
	  
	  $http.get('http://localhost:8080/AssetTool/api/phoneUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getPhoneBySno?sno='+sno;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
             
         
	   })             
    .error(function (error) {  
    	alert('Unable to update the details: Duplicate records found Or Invalid input');
		$window.location.href = 'getPhoneBySno?sno='+sno;
    }); 
}

function PhoneReportCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/phoneReport')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function FinalPhoneReportCtrl ($scope,$http,$window,$routeParams){
	var sno = $routeParams.sno;
	var reportType = $routeParams.reportType;
	
	if(reportType == "current") {
		$http.get('http://localhost:8080/AssetTool/api/getPhoneReport?sno='+sno)
			.success(function (response) {  
				$scope.html = response; 
            	})  
            .error(function (error) {  
            	alert(error);  
       }); 
	}
  if(reportType == "history"){
		 
		$http.get('http://localhost:8080/AssetTool/api/getPhoneHistoryReport?sno='+sno)
		.success(function (response) {  
			$scope.html = response; 
        	})  
        .error(function (error) {  
        	alert(error);  
   }); 
		
	}
}

/// End of Phone controllers ///

//// Start of Laptop controllers  ////
function LaptopAllCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopAll')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
} 

function LaptopAddHomeCtrl ($scope,$http,$window){
	
	$http.get('http://localhost:8080/AssetTool/api/laptopAddHome')
	.success(function (response) {  
        $scope.html = response; 
         
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  


function LaptopAddCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram +  
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 +  "&ea=" + ea ;
		
		
		$http.get('http://localhost:8080/AssetTool/api/laptopAdd?'+input)
		.success(function (response) {  
            $scope.value = response; 
            
            if ($scope.value == "success") {    
            	alert("Laptop Details Added succesfully")
                $window.location.href = 'getLaptopBySno?sno='+sno;
            }
            
            else if($scope.value == "noSessionId") { 
            	alert("please login to continue");
            	$window.location.href = 'loginFail';
            }
            else{
            	alert("Unable to Add the Laptop: Duplicate records found or Invalid input");
            	$window.location.href = 'laptopAddHome';
            }
         })  
           .error(function (error) {  
        	   alert("Unable to Add the Laptop: Duplicate records found or Invalid input");
           	$window.location.href = 'laptopAddHome';
           });  
    }  


function LaptopOnCallCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopOnCall')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  


function LaptopStoresCtrl ($scope, $http){
	$http.get('http://localhost:8080/AssetTool/api/laptopStore')
	.success(function (response) {  
		
        $scope.html = response; 
                   
                 })  
       .error(function (error) {  
          alert(error);  
       });  
}  

function LaptopUpdateHomeCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/laptopUpdate')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function GetLaptopBySnoCtrl ($scope,$http,$window,$routeParams,$location){
	var sno = $routeParams.sno;
	
	$http.get('http://localhost:8080/AssetTool/api/getLaptopDetails?sno='+sno)
		.success(function (response) {
	        $scope.html = response; 
        })  
   .error(function (error) {  
      alert(error);  
   });  
}
function LaptopUpdateCtrl ($scope,$http,$window,$routeParams){
	
	var id = $routeParams.id;  
	var model = $routeParams.model;  
	var hostname = $routeParams.hostname;  
	var vendor = $routeParams.vendor;  
	var sno = $routeParams.sno;  
	var proc_type = $routeParams.proc_type;  
	var hdd = $routeParams.hdd;  
	var ram = $routeParams.ram; 
	var os = $routeParams.os;  
	var os_key = $routeParams.os_key;  
	var pdate = $routeParams.pdate; 
	var warranty = $routeParams.warranty;  
	var edate = $routeParams.edate;  
	var stat = $routeParams.stat;  
	var bond = $routeParams.bond; 
	var uid1 = $routeParams.uid1;  
	var uid2 = $routeParams.uid2;  
	var ea = $routeParams.ea;  
	
	
	var input = "id=" + id + "&model=" + model + "&hostname=" + hostname + "&vendor=" + vendor + 
	"&sno=" + sno + "&proc_type=" + proc_type + "&hdd=" + hdd + "&ram=" + ram +  
	"&os=" + os + "&os_key=" + os_key + "&pdate=" + pdate + "&warranty=" + warranty + "&edate=" +
	edate + "&stat=" + stat + "&bond=" + bond + "&uid1=" + uid1 + "&uid2=" + uid2 +  "&ea=" + ea ;
	  
	  
	   $http.get('http://localhost:8080/AssetTool/api/laptopUpdateFinal?'+input)
	   .success(function (response) {  
     		$scope.value = response; 
				if ($scope.value == "success") {    
              	alert("Details Updated succesfully")
                 $window.location.href = 'getLaptopBySno?sno='+sno;
             }
				else if($scope.value == "noSessionId") { 
	            	alert("please login to continue");
	            	$window.location.href = 'loginFail';
	            }
            
         
	   })             
    .error(function (error) {  
    	alert('Unable to Update Details: Duplicate records found Or Invalid Input');
   	 $window.location.href = 'getLaptopBySno?sno='+sno;
       
    }); 
}
function LaptopReportCtrl ($scope,$http,$window){
	$http.get('http://localhost:8080/AssetTool/api/laptopReport')
	.success(function (response) {  
       		$scope.html = response; 
            })  
       .error(function (error) {  
          alert(error);  
       }); 
}

function FinalLaptopReportCtrl ($scope,$http,$window,$routeParams){
	var sno = $routeParams.sno;
	var reportType = $routeParams.reportType;
	
	if(reportType == "current") {
		$http.get('http://localhost:8080/AssetTool/api/getLaptopReport?sno='+sno)
			.success(function (response) {  
				$scope.html = response; 
            	})  
            .error(function (error) {  
            	alert(error);  
       }); 
	}
	 if(reportType == "history"){
		 
		$http.get('http://localhost:8080/AssetTool/api/getLaptopHistoryReport?sno='+sno)
		.success(function (response) {  
			$scope.html = response; 
        	})  
        .error(function (error) {  
        	alert(error);  
   }); 
		
	}
}

function HomeCtrl($scope, $http) {
}

function ProjectCtrl($scope, $http) {
}

function PrivacyCtrl($scope, $http, $timeout) {
}

function AboutCtrl($scope, $http, $timeout) {
}
