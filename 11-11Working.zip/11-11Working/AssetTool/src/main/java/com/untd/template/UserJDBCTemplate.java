package com.untd.template;
import com.untd.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import javax.sql.DataSource;
import org.springframework.jdbc.core.JdbcTemplate;

public class UserJDBCTemplate  {
   private DataSource dataSource;
   private JdbcTemplate jdbcTemplateObject;
   
   public void setDataSource(DataSource dataSource) {
      this.dataSource = dataSource;
      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
   }

   public String validateLogins(String username, String password){
	   String SQL = "select * from admin";
	   String response ="" ;
	   ArrayList<Admin>  admin = (ArrayList<Admin>) jdbcTemplateObject.query(SQL,new AdminMapper());
	   ListIterator<Admin> li = admin.listIterator();
	   while(li.hasNext()){ 
		     Admin col = li.next();
		     if(col.username.equals(username)){
				   if(col.password.equals(password)){
				   response = "success";
				   break;
				   }
				   else{
					   response = "passwordfail";
					   break;
				   }
			   
		     }
		     else{
			   response = "nousermatch";
			  }
		   }
	   return response;
   }
   
   public ArrayList<User> listUsers() {
	   String SQL = "select * from user";
	   ArrayList <User> users = (ArrayList<User>) jdbcTemplateObject.query(SQL,new UserMapper());
	   return users;
	   }
	      
   public ArrayList<User> getUser(String uid) {
	      String SQL = "select * from user where uid='"+uid+"'";
	      ArrayList <User> userDetails = (ArrayList<User>) jdbcTemplateObject.query(SQL,new UserMapper());
	      return userDetails;
	   }
   
   public String addUser(int id, String fname, String lname, String uid,String team, String role, String stat, String cube, String jdate, String edate) throws Exception{
	   String response;
	   String SQL = "insert into user (id, fname, lname, uid, team, role, stat, cube, jdate, edate) values ('"+id+"', '"+fname+"', '"+lname+"', '"+uid+"', '"+team+"', '"+role+"', '"+stat+"', '"+cube+"', '"+jdate+"', '"+edate+"')";
	   
	   try{
	      jdbcTemplateObject.execute(SQL);
	      System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"User details Added successfully with UID" + uid);
	 	  response="success";
	   }
	   catch (Exception e)	{
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
		   response="fail"; 
		   }
	   return response;
   }
   public String updateUser(int id, String fname, String lname, String uid, String team, String role, String stat, String cube, String jdate, String edate) throws Exception{
		  String response;
		  
		   
		   String SQL = "update user set fname='"+fname+"', lname='"+lname+"' ,"+"uid='"+uid+"' ,"+"team='"+team+"' ,"+"role='"+role+"' ,"+"stat='"+stat+"' ,"+"cube='"+cube+"' ,"+"jdate='"+jdate+"' ,"+"edate='"+edate+"' " +" WHERE id="+id;
		    try{
		    	jdbcTemplateObject.execute(SQL);
		    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"User details update succesfully with UID " + uid);
		    	response="success";
		    }
		    catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   response="fail"; 
			   }
			   return response;
   }
   
   ///  CPU methods ///// 
   public ArrayList<Cpu> listCpus() {
	      String SQL = "select *  from cpu";
	      ArrayList <Cpu> cpus = (ArrayList<Cpu>) jdbcTemplateObject.query(SQL, new CpuMapper());
	      return cpus;
	   }
   public ArrayList<Cpu> listCpu(String mode) {
	      String SQL = "select *  from cpu where stat='"+mode+"'";
	      ArrayList <Cpu> cpus = (ArrayList<Cpu>) jdbcTemplateObject.query(SQL, new CpuMapper());
	      return cpus;
	   }
   public String addCpu(int id, String model,String hostname,String vendor,String sno,String proc_type,String hdd,String ram,
		   String DIMM,String  os,String os_key,String pdate,String warranty,String edate,String stat,String uid1,
		  String flr,String loc,String ea) throws Exception{
		   String response;
		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "insert into cpu (id, model, hostname, vendor, sno, proc_type, hdd, ram,DIMM, os,os_key, pdate, warranty, edate, stat,  uid1, flr, loc, ea)"+
		  "values" + " ('"+id+"', '"+model+"', '"+hostname+"', '"+vendor+"', '"+sno+"', '"+proc_type+"', '"+hdd+"', '"+ram+"', '"+DIMM+"', '"+os+"', '"+os_key+"', '"+pdate+"', '"+
				   warranty+"', '"+edate+"', '"+stat+"',  '"+uid1+"',  '"+flr+"', '"+loc+"', '"+ea+"')";
		   
		   try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"CPU details added successfully with id "+id);
			   response="success";
		   }
		   catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   response="fail"; 
			   }
			   return response;
		   }
   
   public void addCpuHistory(int id,String currentdate, String uid1, String stat, String sno, String adminid){
		String info = "Adding new CPU with SNO "+sno+" to user "+uid1+ " and status updated from new to "+stat+" by "+adminid;
		if(uid1.isEmpty()){
		 info = "Adding new CPU with Serial no "+sno + " By "+adminid;
		}
		String SQL = "insert into history (cpu,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','new','"+stat+"','"+currentdate+"','"+info+"')";
		 try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"CPU details added successfully to the history table with sno " + sno);
			   
		   }
		   catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   
		   }
	}

	public void updateCpuHistory(int id,String currentdate, String uid1, String prevstat, String stat, String sno, String adminid){
		String info = "Status changed for CPU with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
		if(uid1.equals("")){
			 info = "Status changed for CPU SNO "+sno+ " from "+ prevstat +" to "+stat +"  By "+adminid;
		}
		if(prevstat.isEmpty()){
			prevstat = "new";
			info = "Status changed for CPU with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
		}
		String SQL = "insert into history (cpu,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','"+prevstat+"','"+stat+"','"+currentdate+"','"+info+"')";
		System.out.println(SQL);
		 try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"CPU details updated successfully to the history table with sno " + sno);
			   
		   }
		   catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   
		   }
	}

   
   public ArrayList<Cpu> getCpu(String sno) {
	      String SQL = "select * from cpu where sno='"+sno+"'";
	      ArrayList <Cpu> cpuDetails = (ArrayList<Cpu>) jdbcTemplateObject.query(SQL, new CpuMapper());
	      return cpuDetails;
	   }
   
   public String updateCpu(int id, String model,String hostname,String vendor,String sno,String proc_type,String hdd,String ram,
		   String DIMM,String  os,String os_key,String pdate,String warranty,String edate,String stat,String uid1,
		   String flr,String loc,String ea) throws Exception{
		   String response;
		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "update cpu set  model='"+model+"', hostname='"+hostname+"' , sno='"+sno+"' , proc_type='"+proc_type+"' "
		   		+ ", hdd='"+hdd+"' , ram='"+ram+"' , DIMM='"+DIMM+"' , os='"+os+"' , os_key='"+os_key+"' "
		   				+ " , pdate='"+pdate+"' , warranty='"+warranty+"' , edate='"+edate+"' , stat='"+stat+"' "
		   						+ ",  uid1='"+uid1+"' ,  flr='"+flr+"' , loc='"+loc+"' "
		   								+ ", ea='"+ea+"'  WHERE id='"+id+"'";
		   
		   try{
		    jdbcTemplateObject.execute(SQL);
		 	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Cpu details updated successfully with sno "+ sno);
		    response="success";
		   }
		   catch (Exception e)	{
			  System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			  response="fail"; 
			  }
		    return response;
		   }
   
   /// Monitor methods /////
   public ArrayList<Monitor> listMonitor(String mode) {
	      String SQL = "select *  from monitor where stat='"+mode+"'";
	      ArrayList <Monitor> monitors = (ArrayList<Monitor>) jdbcTemplateObject.query(SQL, 
	                                new MonitorMapper());
	      return monitors;
	   }
   public ArrayList<Monitor> listMonitorAll() {
	      String SQL = "select *  from monitor ";
	      ArrayList <Monitor> monitors = (ArrayList<Monitor>) jdbcTemplateObject.query(SQL, 
	                                new MonitorMapper());
	      return monitors;
	   }
   
   
   public String addMonitor(int id, String model,String vendor,String sno,String size,String pdate,String warranty,
		   String edate,String  stat,String uid1) throws Exception{
		  String response;
		  if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "insert into monitor (id, model,  vendor, sno, size,  pdate,warranty, edate,stat,  uid1)"+
		  "values" + " ('"+id+"', '"+model+"',  '"+vendor+"', '"+sno+"', '"+size+"',  '"+pdate+"', '"+warranty+"', '"+edate+"', '"+stat+"',  '"+
				   uid1+"')";
		   
		   try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Monitor details Added succussfully with id " + id);
			   response="success";
		   }
		   catch (Exception e)	{
			  System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			  response="fail"; 
			  }
			   return response;
		   }
   
   
   public void addMonitorHistory(int id,String currentdate, String uid1, String stat, String sno, String adminid){
   	String info = "Adding new Monitor with SNO "+sno+" to user "+uid1+ " and status updated from new to "+stat+" by "+adminid;
   	if(uid1.isEmpty()){
   	 info = "Adding new Monitor with Serial no "+sno + " By "+adminid;
   	}
   	String SQL = "insert into history (monitor,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','new','"+stat+"','"+currentdate+"','"+info+"')";
   	 try{
   		   jdbcTemplateObject.execute(SQL);
   		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Monitor details added successfully to the history table with sno " + sno);
   		   
   	   }
   	   catch (Exception e)	{
   		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
   		   
   	   }
   }

   public void updateMonitorHistory(int id,String currentdate, String uid1, String prevstat, String stat, String sno, String adminid){
   	String info = "Status changed for Monitor with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
   	if(uid1.equals("")){
   		 info = "Status changed for Monitor SNO "+sno+ " from "+ prevstat +" to "+stat +"  By "+adminid;
   	}
   	if(prevstat.isEmpty()){
   		prevstat = "new";
   		info = "Status changed for Monitor with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
   	}
   	String SQL = "insert into history (monitor,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','"+prevstat+"','"+stat+"','"+currentdate+"','"+info+"')";
   	
   	 try{
   		   jdbcTemplateObject.execute(SQL);
   		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Monitor details added successfully to the history table with id " + id);
   		   
   	   }
   	   catch (Exception e)	{
   		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
   		   
   	   }
   }
   
   public ArrayList<Monitor> getMonitor(String sno) {
	      String SQL = "select * from monitor where sno='"+sno+"'";
	      ArrayList <Monitor> monitorDetails = (ArrayList<Monitor>) jdbcTemplateObject.query(SQL, new MonitorMapper());
	      return monitorDetails;
	   }
   
   public String updateMonitor(int id, String model,String vendor,String sno,String size,String pdate,String warranty,
		   String edate,String  stat,String uid1) throws Exception{
		   String response;
		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "update monitor set  model='"+model+"', vendor='"+vendor+"' , sno='"+sno+"' , size='"+size+"' "
		   		+ ", pdate='"+pdate+"' , warranty='"+warranty+"' , edate='"+edate+"' , stat='"+stat+"' "
		   				+ " , uid1='"+uid1+"'    WHERE id='"+id+"'";
		   
		   try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Monitor details Update successfully with sno" + sno);
			   response="success";
		   }
		   catch (Exception e)	{
			  System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			  response="fail"; 
			  }
		  return response;
	   }
   ////// End of monitor methods  ////
   
   //// Start of Phone methods ////
   public ArrayList<Phone> listPhone(String mode) {
	      String SQL = "select *  from phone where stat='"+mode+"'";
	      ArrayList <Phone> phones = (ArrayList<Phone>) jdbcTemplateObject.query(SQL, new PhoneMapper());
	      return phones;
	   }
public ArrayList<Phone> listPhoneAll() {
	      String SQL = "select *  from phone ";
	      ArrayList <Phone> phones = (ArrayList<Phone>) jdbcTemplateObject.query(SQL, new PhoneMapper());
	      return phones;
	   }


public String addPhone(int id, String model,String vendor,String sno,String pdate,String warranty,
		   String edate,String  stat,String uid1) throws Exception{
		   String response;
		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "insert into phone (id, model,  vendor, sno,  pdate,warranty, edate,stat, uid1)"+
		  "values" + " ('"+id+"', '"+model+"',  '"+vendor+"', '"+sno+"',  '"+pdate+"', '"+warranty+"', '"+edate+"', '"+stat+"',  '"+
				   uid1+"')";
		   
		   try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Phone details added successfully with sno" + sno);
			   response="success";
		   }
		   catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   response="fail"; 
		   }
			   return response;
	   }

public void addPhoneHistory(int id,String currentdate, String uid1, String stat, String sno, String adminid){
	String info = "Adding new phone with SNO "+sno+" to user "+uid1+ " and status updated from new to "+stat+" by "+adminid;
	if(uid1.isEmpty()){
	 info = "Adding new phone with Serial no "+sno + " By "+adminid;
	}
	String SQL = "insert into history (phone,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','new','"+stat+"','"+currentdate+"','"+info+"')";
	 try{
		   jdbcTemplateObject.execute(SQL);
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Phone details added successfully to the history table with sno " + sno);
		   
	   }
	   catch (Exception e)	{
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
		   
	   }
}

public void updatePhoneHistory(int id,String currentdate, String uid1, String prevstat, String stat, String sno, String adminid){
	String info = "Status changed for Phone with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
	if(uid1.equals("")){
		 info = "Status changed for Phone SNO "+sno+ " from "+ prevstat +" to "+stat +"  By "+adminid;
	}
	if(prevstat.isEmpty()){
		prevstat = "new";
		info = "Status changed for Phone with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
		
	}
	String SQL = "insert into history (phone,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','"+prevstat+"','"+stat+"','"+currentdate+"','"+info+"')";
	System.out.println(SQL);
	 try{
		   jdbcTemplateObject.execute(SQL);
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Phone details added successfully to the history table with id " + id);
		   
	   }
	   catch (Exception e)	{
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
		   
	   }
}


public ArrayList<Phone> getPhone(String sno) {
	      String SQL = "select * from phone where sno='"+sno+"'";
	      ArrayList <Phone> phoneDetails = (ArrayList<Phone>) jdbcTemplateObject.query(SQL, new PhoneMapper());
	      return phoneDetails;
	   }

public String updatePhone(int id, String model,String vendor,String sno,String pdate,String warranty,
		   String edate,String  stat,String uid1) throws Exception{
		   String response;
		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
		   String SQL = "update phone set  model='"+model+"', vendor='"+vendor+"' , sno='"+sno+"' ,  pdate='"+pdate+"' , warranty='"+warranty+"' , edate='"+edate+"' , stat='"+stat+"' "
		   				+ " ,  uid1='"+uid1+"'    WHERE id='"+id+"'";
		   
		   try{
			   jdbcTemplateObject.execute(SQL);
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Phone details updated successfully with sno " + sno);
			   response="success";
		   }
		   catch (Exception e)	{
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
			   response="fail"; 
		   }
		   return response;
	   }

///start of Laptop methods ///

    public ArrayList<Laptop> listLaptopAll() {
       String SQL = "select *  from laptop ";
       ArrayList <Laptop> laptops = (ArrayList<Laptop>) jdbcTemplateObject.query(SQL,  new LaptopMapper());
       return laptops;
    }

    public String addLaptop(int id, String model,String hostname,String vendor,String sno,String proc_type,String hdd,String ram,
 		   String  os,String os_key,String pdate,String warranty,String edate,String stat,String uid1,
 		   String ea) throws Exception{
 		   String response;
 		  if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
 		   String SQL = "insert into laptop (id, model, hostname, vendor, sno, proc_type,hdd, ram, os,os_key, pdate, warranty, edate, stat, uid1,  ea)"+
 		  "values" + " ('"+id+"', '"+model+"', '"+hostname+"', '"+vendor+"', '"+sno+"', '"+proc_type+"', '"+hdd+"', '"+ram+"',  '"+os+"', '"+os_key+"', '"+pdate+"', '"+
 				   warranty+"', '"+edate+"', '"+stat+"',   '"+uid1+"',   '"+ea+"')";
 		   
 		   try{
 			   jdbcTemplateObject.execute(SQL);
 			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Laptop details Added successfully with id "+ id);
 			   response="success";
 		   }
 		   catch (Exception e)	{
 			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
 			   response="fail"; 
 			  }
 		   return response;
 		}
    
    public void addLaptopHistory(int id,String currentdate, String uid1, String stat, String sno, String adminid){
    	String info = "Adding new Laptop with SNO "+sno+" to user "+uid1+ " and status updated from new to "+stat+" by "+adminid;
    	if(uid1.isEmpty()){
    	 info = "Adding new Laptop with Serial no "+sno + " By "+adminid;
    	}
    	String SQL = "insert into history (laptop,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','new','"+stat+"','"+currentdate+"','"+info+"')";
    	 try{
    		   jdbcTemplateObject.execute(SQL);
    		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Laptop details added successfully to the history table with sno " + sno);
    		   
    	   }
    	   catch (Exception e)	{
    		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
    		   
    	   }
    }

    public void updateLaptopHistory(int id,String currentdate, String uid1, String prevstat, String stat, String sno, String adminid){
    	String info = "Status changed for Laptop with SNO "+sno+ " from "+ prevstat +" to "+stat +" assigned to user "+uid1+"  By "+adminid;
    	if(uid1.equals("")){
    		 info = "Status changed for Laptop SNO "+sno+ " from "+ prevstat +" to "+stat +"  By "+adminid;
    	}
    	if(prevstat.isEmpty()){
    		prevstat = "new";
    	}
    	String SQL = "insert into history (laptop,uid,src,dest,udate,info) values ('"+id+"','"+uid1+"','"+prevstat+"','"+stat+"','"+currentdate+"','"+info+"')";
    	System.out.println(SQL);
    	 try{
    		   jdbcTemplateObject.execute(SQL);
    		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Laptop details added successfully to the history table with id " + id);
    		   
    	   }
    	   catch (Exception e)	{
    		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
    		   
    	   }
    }

    
    
    public ArrayList<Laptop> getLaptop(String mode) {
	      String SQL = "select * from laptop where stat='"+mode+"'";
	      ArrayList <Laptop> laptopDetails = (ArrayList<Laptop>) jdbcTemplateObject.query(SQL,  new LaptopMapper());
	      return laptopDetails;
	   }
    public ArrayList<Laptop> getLaptopBySno(String sno) {
	      String SQL = "select * from laptop where sno='"+sno+"'";
	      ArrayList <Laptop> laptopDetails = (ArrayList<Laptop>) jdbcTemplateObject.query(SQL,  new LaptopMapper());
	      return laptopDetails;
	   }
    
    public String updateLaptop(int id, String model,String hostname,String vendor,String sno,String proc_type,String hdd,String ram,
 		   String  os,String os_key,String pdate,String warranty,String edate,String stat,String uid1, String ea) throws Exception{
 		   String response;
 		   if(edate == ""){
			   edate = "0000-00-00";
		   }
		   if(pdate == ""){
			   pdate = "0000-00-00";
		   }
 		   String SQL = "update laptop set  model='"+model+"', hostname='"+hostname+"' , sno='"+sno+"' , proc_type='"+proc_type+"' "
 		   		+ ", hdd='"+hdd+"' , ram='"+ram+"' ,os='"+os+"' , os_key='"+os_key+"' "
 		   				+ " , pdate='"+pdate+"' , warranty='"+warranty+"' , edate='"+edate+"' , stat='"+stat+"' "
 		   						+ ", uid1='"+uid1+"' ,  ea='"+ea+"'  WHERE id='"+id+"'";
 		   							
 		   
 		   try{
 			   jdbcTemplateObject.execute(SQL);
 			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Laptop details updated successfully with sno " + sno);
 			   response="success";
 		   }
 		   catch (Exception e)	{
 			  System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
 			  response="fail"; 
 		   }
 		   return response;
 	   }
    
    public ArrayList getUserReport(String uid) {
    	  ArrayList<String> list = new ArrayList<String>();
    	  String SQL = "select * from cpu where uid1='"+uid+"'";
	      ArrayList  userCpuDetails = (ArrayList) jdbcTemplateObject.query(SQL,new CpuMapper());
	      list.add("<h3 style='color: black;'>"+uid+"</h3>");
	      /*list.add("<h2 align='center' style='color: black;'> "+ uid +" Asset  details </h2>");*/
	      if(userCpuDetails.size() == 0) {
	    	  list.add("<tr>");
	    	  list.add("<td>CPU</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("</tr>");
	      }
	      else{
	      for (int i = 0; i < userCpuDetails.size() ; i++) {
			  Cpu	cpu = (Cpu) userCpuDetails.get(i);
			  list.add("<tr>");
			  list.add("<td>CPU</td>");
			  list.add("<td>"+cpu.getSno()+"</td>");
			  list.add("<td>"+cpu.getModel()+"</td>");
			  list.add("</tr>");
			  
			}
	      }
	      
	      SQL = "select * from monitor where uid1='"+uid+"'";
	      ArrayList  userMonitorDetails = (ArrayList) jdbcTemplateObject.query(SQL,new MonitorMapper());
	      if(userMonitorDetails.size() == 0) {
	    	  list.add("<tr>");
	    	  list.add("<td>Monitor</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("</tr>");
	      }
	      else{
	    	  for (int i = 0; i < userMonitorDetails.size() ; i++) {
	    		  Monitor	monitor = (Monitor) userMonitorDetails.get(i);
	    		  list.add("<tr>");
	    		  list.add("<td>Monitor</td>");
	    		  list.add("<td>"+monitor.getSno()+"</td>");
	    		  list.add("<td>"+monitor.getModel()+"</td>");
	    		  list.add("</tr>");
	    	  }
	       }
	      
	      SQL = "select * from phone where uid1='"+uid+"'";
	      ArrayList  userPhoneDetails = (ArrayList) jdbcTemplateObject.query(SQL,new PhoneMapper());
	      if(userPhoneDetails.size() == 0) {
	    	  list.add("<tr>");
	    	  list.add("<td>Phone</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("</tr>");
	      }
	      else{
	    	  for (int i = 0; i < userPhoneDetails.size() ; i++) {
	   		  	Phone	phone = (Phone) userPhoneDetails.get(i);
	   		  	list.add("<tr>");
	   		  	list.add("<td>Phone</td>");
	   		  	list.add("<td>"+ phone.getSno()+"</td>");
	   		  	list.add("<td>"+phone.getModel()+"</td>");
	   		  	list.add("</tr>");
		  
	    	  }
	      }
	      
	      SQL = "select * from laptop where uid1='"+uid+"'";
	      
	      ArrayList  userLaptopDetails = (ArrayList) jdbcTemplateObject.query(SQL,new LaptopMapper());
	      if(userLaptopDetails.size() == 0) {
	    	  list.add("<tr>");
	    	  list.add("<td>Laptop</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("<td>NA</td>");
	    	  list.add("</tr>");
	      }
	      else{
	    	  for (int i = 0; i < userLaptopDetails.size() ; i++) {
	    		  Laptop	laptop = (Laptop) userLaptopDetails.get(i);
	    		  list.add("<tr>");
	    		  list.add("<td>Laptop</td>");
	    		  list.add( "<td>"+laptop.getSno()+"</td>");
	    		  list.add("<td>"+laptop.getModel()+"</td>");
	    		  list.add("</tr>");
	    	  }
		}
	      
	      
	     
	      return list;
	   }

    public void updateAssetStatusByUidStatus( String uid) throws Exception{
  		   
  		   String UpdateCpu      =  "update cpu set  stat='Stores' where uid1='"+uid+"'";
  		   String UpdatePhone    =  "update phone set  stat='Stores' where uid1='"+uid+"'";
  		   String UpdateLaptop   =  "update laptop set  stat='Stores' where uid1='"+uid+"'";
  		   String UpdateMonitor  =  "update monitor set  stat='Stores' where uid1='"+uid+"'";
  		   							
  		   
  		   try{
  			   jdbcTemplateObject.execute(UpdateCpu);
  			   jdbcTemplateObject.execute(UpdatePhone);
  			   jdbcTemplateObject.execute(UpdateLaptop);
  			   jdbcTemplateObject.execute(UpdateMonitor);
  			    
  			   
  			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"User: "+uid + " Assets are moved to Stores as the uid status updated to left");
  			  
  		   }
  		   catch (Exception e)	{
  			  System.out.println(java.util.Calendar.getInstance().getTime()+":  "+e);
  			   
  		   }
  		   
  	   }
    
    public ArrayList<Phone> getPhoneReport(String sno) {
	      String SQL = "select *  from phone where sno='"+sno+"'";
	      ArrayList <Phone> phones = (ArrayList<Phone>) jdbcTemplateObject.query(SQL, new PhoneMapper());
	      return phones;
	   }
    public ArrayList<History> getPhoneHistoryReport(int id) {
        String SQL = "select * FROM history where phone='"+id+"'";
        ArrayList <History> phone = (ArrayList<History>) jdbcTemplateObject.query(SQL, new HistoryMapper());
        return phone;
     }
    public ArrayList<Cpu> getCpuReport(String sno) {
	      String SQL = "select *  from cpu where sno='"+sno+"'";
	      ArrayList <Cpu> cpus = (ArrayList<Cpu>) jdbcTemplateObject.query(SQL, new CpuMapper());
	      return cpus;
	   }
    public ArrayList<History> getCpuHistoryReport(int id) {
        String SQL = "select * FROM history where cpu='"+id+"'";
        ArrayList <History> cpu = (ArrayList<History>) jdbcTemplateObject.query(SQL, new HistoryMapper());
        return cpu;
     }
    public ArrayList<Monitor> getMonitorReport(String sno) {
	      String SQL = "select *  from monitor where sno='"+sno+"'";
	      ArrayList <Monitor> monitor = (ArrayList<Monitor>) jdbcTemplateObject.query(SQL, new MonitorMapper());
	      return monitor;
	   }
    public ArrayList<History> getMonitorHistoryReport(int id) {
        String SQL = "select * FROM history where monitor='"+id+"'";
        ArrayList <History> monitor = (ArrayList<History>) jdbcTemplateObject.query(SQL, new HistoryMapper());
        return monitor;
     }
  public ArrayList<Laptop> getLaptopReport(String sno) {
	      String SQL = "select *  from laptop where sno='"+sno+"'";
	      ArrayList <Laptop> laptop = (ArrayList<Laptop>) jdbcTemplateObject.query(SQL, new LaptopMapper());
	      return laptop;
	   }
  public ArrayList<History> getLaptopHistoryReport(int id) {
      String SQL = "select * FROM history where laptop='"+id+"'";
      ArrayList <History> laptop = (ArrayList<History>) jdbcTemplateObject.query(SQL, new HistoryMapper());
      return laptop;
   }
  public int getCpuID(String sno){
	  String SQL = "select * from cpu where sno='"+sno+"'";
	  ArrayList <Cpu> cpu  = (ArrayList<Cpu>) jdbcTemplateObject.query(SQL, new CpuMapper());
	  return cpu.get(0).getId();
			  
  }
  public int getLaptopID(String sno){
	  String SQL = "select * from laptop where sno='"+sno+"'";
	  ArrayList <Laptop> laptop  = (ArrayList<Laptop>) jdbcTemplateObject.query(SQL, new LaptopMapper());
	  return laptop.get(0).getId();
			  
  }
  public int getPhoneID(String sno){
	  String SQL = "select * from phone where sno='"+sno+"'";
	  ArrayList <Phone> phone  = (ArrayList<Phone>) jdbcTemplateObject.query(SQL, new PhoneMapper());
	  return phone.get(0).getId();
			  
  }
  public int getMonitorID(String sno){
	  String SQL = "select * from monitor where sno='"+sno+"'";
	  ArrayList <Monitor> monitor  = (ArrayList<Monitor>) jdbcTemplateObject.query(SQL, new MonitorMapper());
	  return monitor.get(0).getId();
			  
  }
}