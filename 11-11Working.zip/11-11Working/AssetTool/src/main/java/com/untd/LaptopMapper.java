package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class LaptopMapper implements RowMapper {
   public Laptop mapRow(ResultSet rs, int rowNum) throws SQLException {
      Laptop laptop = new Laptop();
      laptop.setId(rs.getInt("id"));
      laptop.setModel(rs.getString("model"));
      laptop.setHostname(rs.getString("hostname"));
      laptop.setVendor(rs.getString("vendor"));
      laptop.setSno(rs.getString("sno"));
      laptop.setProc_type(rs.getString("proc_type"));
      laptop.setHdd(rs.getString("hdd"));
      laptop.setRam(rs.getString("ram"));
      
      laptop.setOs(rs.getString("os")); 
      laptop.setOs_key(rs.getString("os_key")); 
      laptop.setPdate(rs.getString("pdate")); 
      laptop.setWarranty(rs.getString("warranty")); 
      laptop.setEdate(rs.getString("edate")); 
      laptop.setStat(rs.getString("stat")); 
      laptop.setBond(rs.getString("bond"));
      laptop.setUid1(rs.getString("uid1")); 
      laptop.setUid2(rs.getString("uid2"));
      laptop.setEa(rs.getString("ea"));
      
      return laptop;
   }
}