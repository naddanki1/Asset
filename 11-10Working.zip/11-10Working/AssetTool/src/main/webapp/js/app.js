﻿
'use strict';

// angular.js main app initialization
var app = angular.module('AssetTool', []).
    config(['$routeProvider','$locationProvider','$httpProvider',function ($routeProvider,$locationProvider,$httpProvider) {
    	
    	$locationProvider.html5Mode({
            enabled: true,
           
      });
    	$routeProvider.
    	when('/', { 
        	templateUrl: 'pages/index.html' 
        	
        	}).
      	            	  
        when('/homeFarword', { 
            templateUrl: 'pages/commonBind.html',
            controller: LoginCheckCtrl
            }).
            
        when('/home', { 
           	templateUrl: 'pages/home.html'
            }).
       
      /////  USERS Mapping ///////      
        when('/users', {
           	templateUrl: 'pages/users.html',
            }). 
            	
		when('/userUpdate',{
            templateUrl: 'pages/commonBind.html',
            controller: UserUpdateCtrl
			}).
			
       /* when('/userAdd',{
            templateUrl: 'pages/userAdd.html',
            }).*/
			
	    when ('/userAddHome',{
	        	templateUrl: 'pages/commonBind.html',
	        	controller: UserAddHomeCtrl
	        }).
	    when ('/userAdd',{
	        	templateUrl: 'pages/commonBind.html',
	        	controller: UserAddCtrl
	        }).
            
        when('/userUpdateHome',{
           	templateUrl: 'pages/commonBind.html',
            controller: UserUpdateHomeCtrl
            }).
        
        when('/getUserByUID',{  
            templateUrl: 'pages/commonBind.html',
            controller: GetUserByUIDCtrl
            }).  
              
        when('/userDetails',{
            templateUrl: 'pages/commonBind.html',
            controller: UserDetailCtrl
            }).
        when('/userReport',{
                templateUrl: 'pages/commonBind.html',
                controller: UserReportCtrl
    			}).
    	when('/getUserReport',{
                    templateUrl: 'pages/commonBind.html',
                    controller: FinalUserReportCtrl
        			}).
        when('/reportHome',{
                    templateUrl: 'pages/reportHome.html',
                    
            			}).
        //// END of USERS ///////////////////    
        
            
       ///// CPU Mapping /////////////////////     
            
        when('/cpu', {
            	templateUrl: 'pages/cpu.html',
            	}).
        when ('/cpuDetails',{
        	templateUrl: 'pages/commonBind.html',
        	controller: CpuDetailCtrl
        }).
       /* when ('/cpuAdd',{
        	templateUrl: 'pages/cpuAdd.html',
        	
        }).*/
        when ('/cpuAddHome',{
        	templateUrl: 'pages/commonBind.html',
        	controller: CpuAddHomeCtrl
        }).
        when ('/cpuAdd',{
        	templateUrl: 'pages/commonBind.html',
        	controller: CpuAddCtrl
        }).
        when('/cpuUpdateHome',{
           	templateUrl: 'pages/commonBind.html',
            controller: CpuUpdateHomeCtrl
            }).	
        when('/getCpuBySno',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetCpuBySnoCtrl
                }). 
        when('/cpuUpdate',{
                templateUrl: 'pages/commonBind.html',
                controller: CpuUpdateCtrl
        		}).
        when ('/cpuStores',{
              	  templateUrl: 'pages/commonBind.html',
              	  controller: CpuStoreCtrl
               }).
        when ('/cpuDesktop',{
            	  templateUrl: 'pages/commonBind.html',
            	  controller: CpuDesktopCtrl
              }).
        
        when ('/cpuOut',{
              	  templateUrl: 'pages/commonBind.html',
              	  controller: CpuOutCtrl
                }).
            	
       //// END of CPU /////////////////////////     	
      
        		
      //// Start of Monitor mapping ////////   		
        		
       when('/monitors', {
          	templateUrl: 'pages/monitors.html',
          	}).
       when ('/monitorAll',{
          	  templateUrl: 'pages/commonBind.html',
          	  controller: MonitorAllCtrl
           }).
           
       when ('/monitorAddHome',{
              	templateUrl: 'pages/commonBind.html',
              	controller: MonitorAddHomeCtrl
              }).
       when ('/monitorAdd',{
              	templateUrl: 'pages/commonBind.html',
              	controller: MonitorAddCtrl
              }). 
       when('/getMonitorBySno',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetMonitorBySnoCtrl
                }). 
        
        when ('/monitorStores',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorStoreCtrl
         }).
        when ('/monitorDesktop',{
      	  templateUrl: 'pages/commonBind.html',
      	  controller: MonitorDesktopCtrl
        }).
        when ('/monitorFaulty',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorFaultyCtrl
          }).
        when ('/monitorOut',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorOutCtrl
          }).
       
        when('/monitorUpdateHome',{
             	templateUrl: 'pages/commonBind.html',
                 controller: MonitorUpdateHomeCtrl
              }).
              
        when('/monitorUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: MonitorUpdateCtrl
      			}).
       
     //// END of monitor Mapping //// 	
      			
     //// Start of phone mapping ////
        when('/phones', {
      	       templateUrl: 'pages/phones.html',
      	    }).
        when ('/phoneAll',{
          	  templateUrl: 'pages/commonBind.html',
          	  controller: PhoneAllCtrl
           }).
           
       when ('/phoneAddHome',{
           	templateUrl: 'pages/commonBind.html',
           	controller: PhoneAddHomeCtrl
           }).
       when ('/phoneAdd',{
           	templateUrl: 'pages/commonBind.html',
           	controller: PhoneAddCtrl
           }). 
        
        when('/getPhoneBySno',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetPhoneBySnoCtrl
                }). 
        
        when ('/phoneStores',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneStoreCtrl
         }).
        when ('/phoneDesktop',{
      	  templateUrl: 'pages/commonBind.html',
      	  controller: PhoneDesktopCtrl
        }).
        when ('/phoneFaulty',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneFaultyCtrl
          }).
        when ('/phoneOut',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneOutCtrl
          }).
       
        when('/phoneUpdateHome',{
             	templateUrl: 'pages/commonBind.html',
                 controller: PhoneUpdateHomeCtrl
              }).
              
        when('/phoneUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: PhoneUpdateCtrl
      			}). 
      	    
      	    
      	    
     //// End of phone mapping //// 	    
      	    
     /// Start of laptop Mapping ////
       when('/laptop', {
           	templateUrl: 'pages/laptops.html',
           	}). 
       when ('/laptopAll',{
            	templateUrl: 'pages/commonBind.html',
            	controller: LaptopAllCtrl
            }).
       when ('/laptopAddHome',{
               	templateUrl: 'pages/commonBind.html',
               	controller: LaptopAddHomeCtrl
               }).
       when ('/laptopAdd',{
               	templateUrl: 'pages/commonBind.html',
               	controller: LaptopAddCtrl
               }). 
       when ('/laptopOnCall',{
            	templateUrl: 'pages/commonBind.html',
            	controller:   LaptopOnCallCtrl
            }).
       when ('/laptopStores',{
            	templateUrl: 'pages/commonBind.html',
            	controller:   LaptopStoresCtrl
            }).
       when('/laptopUpdateHome',{
             	 templateUrl: 'pages/commonBind.html',
                 controller: LaptopUpdateHomeCtrl
              }).
              
       when('/laptopUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: LaptopUpdateCtrl
      			}).
       when('/getLaptopBySno',{  
                    templateUrl: 'pages/commonBind.html',
                    controller: GetLaptopBySnoCtrl
                    }).   
                  	
    /////////////////Report mapping //////
                when('/reportHome',{
                        templateUrl: 'pages/reportHome.html',
                        
                		}).
                when('/userReport',{
                        templateUrl: 'pages/commonBind.html',
                        controller: UserReportCtrl
            			}).
            	when('/getUserReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: FinalUserReportCtrl
                			}).
                			
                when('/cpuReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: CpuReportCtrl
                     			}).
                when('/getCpuReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: FinalCpuReportCtrl
                       			}).
                			
                when('/phoneReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: PhoneReportCtrl
                   			}).
               	when('/getPhoneReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: FinalPhoneReportCtrl
                    			}).
                when('/laptopReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: LaptopReportCtrl
                      			}).
                when('/getLaptopReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: FinalLaptopReportCtrl
                       			}).
                        			
                when('/monitorReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: MonitorReportCtrl
                      			}).
               	when('/getMonitorReport',{
                            templateUrl: 'pages/commonBind.html',
                            controller: FinalMonitorReportCtrl
                      			}).             
            	
    //// End of laptop mapping /////       	
           	
        when('/phones', {
          	templateUrl: 'pages/phones.html',
            }).
        when('/loginFail',{
        	templateUrl: 'pages/loginRedirect.html'
        }).
       
            
        when('/logout', {
        	templateUrl: 'pages/commonBind.html',
            controller: LogoutCtrl
           }) ;

    }]);
    
/*app.run(['$location', function AppRun($location) {
    debugger; // -->> here i debug the $location object to see what angular see's as URL
}]);*/

