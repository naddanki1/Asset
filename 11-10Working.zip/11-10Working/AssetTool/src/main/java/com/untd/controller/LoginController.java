package com.untd.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Scope;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.untd.User;
import com.untd.template.UserJDBCTemplate;

@Controller
@Scope("session")


public class LoginController {
	ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

@RequestMapping(value="/login",method = RequestMethod.GET, produces = "application/json",params = {"username","password"})

public @ResponseBody ()
String getUser(@RequestParam(value = "username") String username,  @RequestParam(value = "password") String password ,HttpServletRequest request,  HttpSession session) {
   
	String response = userJDBCTemplate.validateLogins(username,password);
	if(response.equals("success")){
		session.setAttribute("login", "success");
		session.setAttribute("adminid", username);
	}
	return response;
}

@RequestMapping(value="/logout")

public @ResponseBody ()
String clearSession(HttpServletRequest request, HttpSession session) {
     
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
	 request.getSession().invalidate();
	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"User loggedout successfully ");
	 return "Logout";	
    }
	else{
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"User not logged in but tried logout");
		return "notloggedin";
	}
}


@RequestMapping(value="/checkLogin",produces = "application/json")
public @ResponseBody () 
String checkLogin ( HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
                	return "Success";	
        	 }
	 else {
				
		 return "Fail";
	 	}
}



}
