package com.untd;
import com.untd.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

public class UserMapper implements RowMapper {
   public User mapRow(ResultSet rs, int rowNum) throws SQLException {
      User user = new User();
      user.setId(rs.getInt("id"));
      user.setFname(rs.getString("fname"));
      user.setLname(rs.getString("lname"));
      user.setUid(rs.getString("uid"));
      user.setCube(rs.getString("cube"));
      user.setEdate(rs.getString("edate"));
      user.setJdate(rs.getString("jdate"));
      user.setRole(rs.getString("role"));
      user.setStat(rs.getString("stat"));
      user.setTeam(rs.getString("team")); 	
      return user;
   }
}