package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller


public class UserController {
	ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");


@RequestMapping(value="/userDetails")
public String getUserDetails (ModelMap model , HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
        System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting User details");
		ArrayList users =  userJDBCTemplate.listUsers();
     	model.addAttribute("message", users);
        return "users";	
    }
	 else {
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get User details: User not logged in");
		return "redirect:/api/home";
		              
	}
}

@RequestMapping(value="/userUpdate")
public String getUpdateUserDetails (ModelMap model,HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting  User details to update");
		ArrayList users =  userJDBCTemplate.listUsers();
     	model.addAttribute("message", users);
        return "userUpdateHome";	
    }
	else{
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get User details to update: User not logged in");
		return "redirect:/api/home";
		}
}



@RequestMapping(value="/home")
public String redirectToHome (ModelMap model){
	         	return "home";	
}
@RequestMapping(value="/userAddHome")
public String cpuAddHome (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting user adding form ");
	   
	    
         	return "userAddHome";	
	    }
	    else{
	    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get cpu add page  :User not logged in");
	   		 return "redirect:/api/home";
	   		              
	   	}
 }

@RequestMapping(value="/getUserDetails")
public String getUser (@RequestParam String  uid,ModelMap model,HttpSession session) {
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting user details by userid: "+ uid);
		ArrayList users =  userJDBCTemplate.getUser(uid );
     	model.addAttribute("message", users);
     	return "userByUID";	
    }
	else {
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
		return "redirect:/api/home";
	}
}
	

@RequestMapping(value="/userUpdateFinal",produces = "application/json", params = {"id","fname","lname","uid","team","role","stat","cube","jdate","edate"})
public @ResponseBody () 
 String UpdateUser (@RequestParam (value = "id") int id,  @RequestParam(value = "fname") String fname, @RequestParam(value = "lname") String lname,@RequestParam(value = "uid") String uid,
		 @RequestParam(value = "team") String team, @RequestParam(value = "role") String role , @RequestParam(value = "stat") String stat, @RequestParam(value = "cube") String cube,
		 @RequestParam(value = "jdate") String jdate,@RequestParam(value = "edate") String edate,HttpSession session) throws Exception{
	String loginAttribute = (String) session.getAttribute("login");
	if (loginAttribute == "success"){
		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Updating user details");
		
		if (stat.equals("Left")){
			userJDBCTemplate.updateAssetStatusByUidStatus( uid ) ;
		}
		String res =  userJDBCTemplate.updateUser(id,fname,lname,uid,team,role,stat,cube,jdate,edate);
     	
        return res;	
    }
	
	else{
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to update the User deatils: User not logged in");
		 return "noSessionId";
	 }
}

 @RequestMapping(value="/userAdd",produces = "application/json", params = {"id","fname","lname","uid","team","role","stat","cube","jdate","edate"})
 public @ResponseBody ()  	
 String addUser(@RequestParam (value = "id") int id,  @RequestParam(value = "fname") String fname, @RequestParam(value = "lname") String lname,@RequestParam(value = "uid") String uid,
		 @RequestParam(value = "team") String team, @RequestParam(value = "role") String role , @RequestParam(value = "stat") String stat, @RequestParam(value = "cube") String cube,
		 @RequestParam(value = "jdate") String jdate,@RequestParam(value = "edate") String edate,HttpSession session) throws Exception{
	 
	 String loginAttribute = (String) session.getAttribute("login");
	 if (loginAttribute == "success"){
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Adding user details with uid "+uid);
	 	 String response = userJDBCTemplate.addUser(id,fname,lname,uid,team,role,stat,cube,jdate,edate);
	 	     
	 	 return response; 
     }
	 else{
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to add user details: User not logged in");
		 return "noSessionId";
	 }
 }
 
 
 
} 
