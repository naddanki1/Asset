package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller
public class ReportController {
     ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

	 @RequestMapping(value="/userReport")
	 public String getUser (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting User Report");
	    	ArrayList report =  userJDBCTemplate.listUsers();
     		model.addAttribute("message", report);
         	return "userReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 @RequestMapping(value="/getUserReport")
	 public String getUserReport (@RequestParam String  uid,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting user reports by userid: "+ uid);
	 		ArrayList users =  userJDBCTemplate.getUserReport(uid );
	      	model.addAttribute("message", users);
	      	return "userReportByUID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 @RequestMapping(value="/phoneReport")
	 public String getPhone (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone Report");
	    	ArrayList report =  userJDBCTemplate.listPhoneAll();
     		model.addAttribute("message", report);
         	return "phoneReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 
	 @RequestMapping(value="/getPhoneReport")
	 public String getPhoneReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getPhoneReport(id );
	      	model.addAttribute("message", users);
	      	return "phoneReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Phone details by id: User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 
	 @RequestMapping(value="/getPhoneHistoryReport")
	 public String getPhoneHistoryReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Phone History reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getPhoneHistoryReport(id );
	      	model.addAttribute("message", users);
	      	return "phoneHistoryReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Phone History details by id : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 @RequestMapping(value="/cpuReport")
	 public String getCPU (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Cpu Report");
	    	ArrayList report =  userJDBCTemplate.listCpus();
     		model.addAttribute("message", report);
         	return "cpuReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 
	 @RequestMapping(value="/getCpuReport")
	 public String getCpuReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting CPU reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getCpuReport(id );
	      	model.addAttribute("message", users);
	      	return "cpuReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 @RequestMapping(value="/getCpuHistoryReport")
	 public String getCpuHistoryReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting CPU History reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getCpuHistoryReport(id );
	      	model.addAttribute("message", users);
	      	return "cpuHistoryReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get CPU History details by id : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 @RequestMapping(value="/laptopReport")
	 public String getLaptop (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop Report");
	    	ArrayList report =  userJDBCTemplate.listLaptopAll();
     		model.addAttribute("message", report);
         	return "laptopReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 
	 @RequestMapping(value="/getLaptopReport")
	 public String getLaptopReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getLaptopReport(id );
	      	model.addAttribute("message", users);
	      	return "laptopReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop details by id : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 @RequestMapping(value="/getLaptopHistoryReport")
	 public String getLaptopHistoryReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Laptop History reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getLaptopHistoryReport(id );
	      	model.addAttribute("message", users);
	      	return "laptopHistoryReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Laptop History details by id : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 @RequestMapping(value="/monitorReport")
	 public String getMonitor (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor Report");
	    	ArrayList report =  userJDBCTemplate.listMonitorAll();
     		model.addAttribute("message", report);
         	return "monitorReportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 
	 @RequestMapping(value="/getMonitorReport")
	 public String getMonitorReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getMonitorReport(id );
	      	model.addAttribute("message", users);
	      	return "monitorReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor details by id: User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
	 
	 @RequestMapping(value="/getMonitorHistoryReport")
	 public String getMonitorHistoryReport (@RequestParam String  id,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Monitor History reports by id: "+ id);
	 		ArrayList users =  userJDBCTemplate.getMonitorHistoryReport(id );
	      	model.addAttribute("message", users);
	      	return "monitorHistoryReportByID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Monitor History details by id : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
}