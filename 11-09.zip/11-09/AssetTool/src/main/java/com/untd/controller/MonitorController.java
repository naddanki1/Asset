package com.untd.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.untd.template.UserJDBCTemplate;

@Controller
public class MonitorController {
	ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
	UserJDBCTemplate userJDBCTemplate = (UserJDBCTemplate)context.getBean("userJDBCTemplate");
	 
	@RequestMapping(value = "/monitorAll")
	public String getMonitorAll(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting monitoring details by Admin "+adminid);
			String mode = "*";
			
			ArrayList monitors =  userJDBCTemplate.listMonitorAll();
     		model.addAttribute("message", monitors);
         	return "monitorAll";	        }
	   else {
	 	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get monitor details : User not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/monitorAddHome")
	 public String cpuAddHome (ModelMap model, HttpSession session) {
		    String loginAttribute = (String) session.getAttribute("login");
		    if (loginAttribute == "success"){ 
		    String adminid = (String) session.getAttribute("adminid");
	 	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting Monitor add page by Admin"+adminid);
	 	   
		    
	          	return "monitorAddHome";	
		    }
		    else{
		    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get monitor add page  :User not logged in");
		   		 return "redirect:/api/home";
		   		              
		   	}
	  }
	 
	
	@RequestMapping(value="/monitorAdd",produces = "application/json", params = {"id","model","vendor","sno","size","pdate","warranty","edate","stat","uid1"})
	 public @ResponseBody ()  	
	 String addMonitor(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "size") String size,  @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
             @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat, 
			 @RequestParam(value = "uid1") String uid1,  HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){
			 String adminid = (String) session.getAttribute("adminid");
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Adding monitor details by Admin "+adminid);
			 String response = userJDBCTemplate.addMonitor(id,model,vendor,sno,size,pdate,warranty,edate,stat,uid1);
		     
			 return response; 
	     }
		 else{
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to add monitor details: User not logged in");
			 return "noSessionId";
		 }
	 }
	
	@RequestMapping(value="/monitorUpdate")
	public String getUpdateUserDetails (ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor details to update by Admin  "+adminid);
			ArrayList monitors =  userJDBCTemplate.listMonitorAll();
	     	model.addAttribute("message", monitors);
	        return "monitorUpdateHome";	
	    }
		else{
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to  the monitor details: User not logged in");
			return "redirect:/api/home";
			}
	}
	
	@RequestMapping(value="/monitorUpdateFinal",produces = "application/json",params = {"id","model","vendor","sno","size","pdate","warranty","edate","stat","uid1"})
	 public @ResponseBody ()  	
	 String updateMonitor(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "vendor") String vendor,@RequestParam(value = "sno") String sno,
			 @RequestParam(value = "size") String size,  @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
            @RequestParam(value = "edate") String edate, @RequestParam(value = "stat") String stat, 
			 @RequestParam(value = "uid1") String uid1, HttpSession session) throws Exception{
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){ 
			 String adminid = (String) session.getAttribute("adminid");
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Updating monitor details by admin "+adminid);
		     String res =  userJDBCTemplate.updateMonitor(id,model,vendor,sno,size,pdate,warranty,edate,stat,uid1);
	     	 return res;	
	    }
		else{
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to Update monitor details: User not logged in"); 
			 return "noSessionId";
		 }
	}
	@RequestMapping(value = "/monitorStore")
	public String getMonitorStore(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor store details by Admin "+adminid);
			String mode = "Stores";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorStores";	
        }
	   else {
	 	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the monitor store details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/monitorDesktop")
	public String getMonitorDesktop(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor desktop details by Admin "+adminid);
			String mode = "Desktop";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorDesktop";	
        }
	   else {
		    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the monitor desktop details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	@RequestMapping(value = "/monitorFaulty")
	public String getMonitorFaulty(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor faulty details by Admin "+adminid);
			String mode = "Faulty";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorFaulty";	
        }
	   else {
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the monitor faulty details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value = "/monitorOut")
	public String getMonitorOut(ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor out details by Admin "+adminid);
			String mode = "Out";
			ArrayList monitors =  userJDBCTemplate.listMonitor(mode);
     		model.addAttribute("message", monitors);
         	return "monitorOut";	
        }
	   else {
		   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the monitor out details: User  not logged in");
		    return "redirect:/api/home";
		   }
      }
	
	@RequestMapping(value="/getMonitorDetails")
	public String getUser (@RequestParam String  sno,ModelMap model,HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting monitor details by SNo:  "+ sno+" by Admin "+adminid);
			ArrayList monitors =  userJDBCTemplate.getMonitor(sno );
	     	model.addAttribute("message", monitors);
	     	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+monitors);
	        return "monitorBySno";	
	    }
		else {
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get the monitor details By sno : User  not logged in");
				return "redirect:/api/home";
		}
	}
	
}
	


