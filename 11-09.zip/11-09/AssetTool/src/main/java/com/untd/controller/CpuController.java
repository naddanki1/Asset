package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller
public class CpuController {
     ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

	 @RequestMapping(value="/cpuStores")
     public String getUserDetails (ModelMap model , HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	String adminid = (String) session.getAttribute("adminid");
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting CPU details by Admin "+adminid);
	    	ArrayList cpus =  userJDBCTemplate.listCpus();
     		model.addAttribute("message", cpus);
         	return "cpu";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 @RequestMapping(value="/cpuAdd", produces = "application/json", params = {"id","model", "hostname", "vendor", "sno", "proc_type", "hdd", "ram", "DIMM", "os","os_key", "pdate", "warranty", "edate", "stat",  "uid1",  "flr", "loc", "ea" })
	 public @ResponseBody ()  	
	 String addUser(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "hostname") String hostname,@RequestParam(value = "vendor") String vendor,
	 @RequestParam (value = "sno") String sno,  @RequestParam(value = "proc_type") String proc_type, @RequestParam(value = "hdd") String hdd,
	 @RequestParam (value = "ram") String ram,  @RequestParam(value = "DIMM") String DIMM, @RequestParam(value = "os") String os,
	 @RequestParam (value = "os_key") String os_key,  @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
	 @RequestParam (value = "edate") String edate,  @RequestParam(value = "stat") String stat, @RequestParam (value = "uid1") String uid1,	   
	 @RequestParam (value = "flr") String flr,  @RequestParam(value = "loc") String loc, @RequestParam(value = "ea") String ea,HttpSession session) throws Exception{
	      
		 
		 String loginAttribute = (String) session.getAttribute("login");
		 if (loginAttribute == "success"){
			 String adminid = (String) session.getAttribute("adminid"); 
		       String response = userJDBCTemplate.addCpu(id,model, hostname, vendor, sno, proc_type, hdd, ram,DIMM, os,os_key, pdate, warranty, edate, stat,  uid1, flr, loc, ea);
		       System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Adding CPU by Admin "+adminid);    
		       return response; 
         }
		 else{
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to add cpu: user not logged in");
			 return "noSessionId";
		 }
 }
	
	 @RequestMapping(value="/cpuUpdate")
	 public String getUpdateUserDetails (ModelMap model, HttpSession session) {
		    String loginAttribute = (String) session.getAttribute("login");
		    
		    if (loginAttribute == "success"){
		    	String adminid = (String) session.getAttribute("adminid");
		    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting Cpu details by Admin "+ adminid);
		    	ArrayList cpus =  userJDBCTemplate.listCpus();
		    	model.addAttribute("message", cpus);
	          	return "cpuUpdateHome";	
		    }
		    else{
		    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get CPU details for CpuUpdate :User not logged in");
		   		 return "redirect:/api/home";
		   		              
		   	}
	  }
	 @RequestMapping(value="/cpuAddHome")
	 public String cpuAddHome (ModelMap model, HttpSession session) {
		    String loginAttribute = (String) session.getAttribute("login");
		    if (loginAttribute == "success"){
		    	String adminid = (String) session.getAttribute("adminid");
		    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"getting Cpu details by Admin "+adminid);
	 	   
 		    
	          	return "cpuAddHome";	
		    }
		    else{
		    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get cpu add page  :User not logged in");
		   		 return "redirect:/api/home";
		   		              
		   	}
	  }
	 
	 
	 
	 @RequestMapping(value="/getCpuDetails")
	 public String getUser (@RequestParam String sno,ModelMap model, HttpSession session) {
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting Cpu details by sno: "+ sno+ " by Admin "+adminid);
			ArrayList cpu =  userJDBCTemplate.getCpu(sno);
	      	model.addAttribute("message", cpu);
	       	return "cpuBySno";	
	    }
		else{
	    	 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to getCpuDetails by ID : User not logged in");
	   		 return "redirect:/api/home";
	   		              
	   	}
 }
	 @RequestMapping(value="/cpuUpdateFinal",produces = "application/json", params = {"id","model", "hostname", "vendor", "sno", "proc_type", "hdd", "ram", "DIMM", "os","os_key", "pdate", "warranty", "edate", "stat", "uid1",  "flr", "loc", "ea" })
	 public @ResponseBody ()  	
	 String updateCPU(@RequestParam (value = "id") int id,  @RequestParam(value = "model") String model, @RequestParam(value = "hostname") String hostname,@RequestParam(value = "vendor") String vendor,
	 @RequestParam (value = "sno") String sno,  @RequestParam(value = "proc_type") String proc_type, @RequestParam(value = "hdd") String hdd,
	 @RequestParam (value = "ram") String ram,  @RequestParam(value = "DIMM") String DIMM, @RequestParam(value = "os") String os,
	 @RequestParam (value = "os_key") String os_key,  @RequestParam(value = "pdate") String pdate, @RequestParam(value = "warranty") String warranty,
	 @RequestParam (value = "edate") String edate,  @RequestParam(value = "stat") String stat,	 @RequestParam (value = "uid1") String uid1,  
	 @RequestParam (value = "flr") String flr,  @RequestParam(value = "loc") String loc, @RequestParam(value = "ea") String ea,HttpSession session) throws Exception{
		 
		String loginAttribute = (String) session.getAttribute("login");
		if (loginAttribute == "success"){ 
			String adminid = (String) session.getAttribute("adminid");
			System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Updating Cpu details by Admin "+adminid);
	 	
			String res =  userJDBCTemplate.updateCpu(id,model, hostname, vendor, sno, proc_type, hdd, ram,DIMM, os,os_key, pdate, warranty, edate, stat, uid1, flr, loc, ea);
	 	
			return res;	
	    }
		else{
			 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Fialed to update Cpu details: User not logged in");
			 return "noSessionId";
		 }
		
	 }
	 @RequestMapping(value = "/cpuStore")
		public String getcpuStore(ModelMap model, HttpSession session) {
			String loginAttribute = (String) session.getAttribute("login");
			if (loginAttribute == "success"){
				String adminid = (String) session.getAttribute("adminid");
				System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting stores cpu details by Admin "+adminid);
				String mode = "Stores";
				ArrayList cpus =  userJDBCTemplate.listCpu(mode);
	     		model.addAttribute("message", cpus);
	         	return "cpuStores";	
	        }
		   else {
		 	    System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get stores cpu details : User  not logged in");
			    return "redirect:/api/home";
			   }
	      }
		@RequestMapping(value = "/cpuDesktop")
		public String getcpuDesktop(ModelMap model, HttpSession session) {
			String loginAttribute = (String) session.getAttribute("login");
			if (loginAttribute == "success"){
				String adminid = (String) session.getAttribute("adminid");
				System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting desktop cpu details by Admin "+adminid);
				String mode = "Desktop";
				ArrayList cpus =  userJDBCTemplate.listCpu(mode);
	     		model.addAttribute("message", cpus);
	         	return "cpuDesktop";	
	        }
		   else {
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Desktop cpu details : User  not logged in");
			    return "redirect:/api/home";
			   }
	      }
		
		
		@RequestMapping(value = "/cpuOut")
		public String getcpuOut(ModelMap model, HttpSession session) {
			String loginAttribute = (String) session.getAttribute("login");
			if (loginAttribute == "success"){
				String adminid = (String) session.getAttribute("adminid");
				System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting out CPU details by Admin "+adminid);
				String mode = "Out";
				ArrayList cpus =  userJDBCTemplate.listCpu(mode);
	     		model.addAttribute("message", cpus);
	         	return "cpuOut";	
	        }
		   else {
			   System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Out cpu details : User  not logged in");
			    return "redirect:/api/home";
			   }
	      }
		
}
