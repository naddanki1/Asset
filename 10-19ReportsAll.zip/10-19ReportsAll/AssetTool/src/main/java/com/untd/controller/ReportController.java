package com.untd.controller;

import com.untd.User;
import com.untd.template.*;

import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

@Controller
public class ReportController {
     ApplicationContext context = 
            new ClassPathXmlApplicationContext("Beans.xml");
	 UserJDBCTemplate userJDBCTemplate = 
		      (UserJDBCTemplate)context.getBean("userJDBCTemplate");

	 @RequestMapping(value="/userReport")
	 public String getUser (ModelMap model, HttpSession session) {
	    String loginAttribute = (String) session.getAttribute("login");
	    if (loginAttribute == "success"){
	    	System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting User Report");
	    	ArrayList report =  userJDBCTemplate.listUsers();
     		model.addAttribute("message", report);
         	return "reportHome";	
    }
	 else {
		 System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Cpu details : user not  logged in");  
		 return "redirect:/api/home";
     }
    }
	 
	 @RequestMapping(value="/getUserReport")
	 public String getUserReport (@RequestParam String  uid,ModelMap model,HttpSession session) {
	 	String loginAttribute = (String) session.getAttribute("login");
	 	if (loginAttribute == "success"){
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Getting user reports by userid: "+ uid);
	 		ArrayList users =  userJDBCTemplate.getUserReport(uid );
	      	model.addAttribute("message", users);
	      	return "userReportByUID";	
	     }
	 	else {
	 		System.out.println(java.util.Calendar.getInstance().getTime()+":  "+"Failed to get Userdetails by uid : User not logged in");
	 		return "redirect:/api/home";
	 	}
	 }
}