﻿
'use strict';

// angular.js main app initialization
var app = angular.module('AssetTool', []).
    config(['$routeProvider','$locationProvider','$httpProvider',function ($routeProvider,$locationProvider,$httpProvider) {
    	
    	$locationProvider.html5Mode({
            enabled: true,
           
      });
    	$routeProvider.
    	when('/', { 
        	templateUrl: 'pages/index.html' 
        	
        	}).
      	            	  
        when('/homeFarword', { 
            templateUrl: 'pages/commonBind.html',
            controller: LoginCheckCtrl
            }).
            
        when('/home', { 
           	templateUrl: 'pages/home.html'
            }).
       
      /////  USERS Mapping ///////      
        when('/users', {
           	templateUrl: 'pages/users.html',
            }). 
            	
		when('/userUpdate',{
            templateUrl: 'pages/commonBind.html',
            controller: UserUpdateCtrl
			}).
			
        when('/userAdd',{
            templateUrl: 'pages/userAdd.html',
            }).
            
        when('/userUpdateHome',{
           	templateUrl: 'pages/commonBind.html',
            controller: UserUpdateHomeCtrl
            }).
        
        when('/getUserByUID',{  
            templateUrl: 'pages/commonBind.html',
            controller: GetUserByUIDCtrl
            }).  
              
        when('/userDetails',{
            templateUrl: 'pages/commonBind.html',
            controller: UserDetailCtrl
            }).
        when('/report',{
                templateUrl: 'pages/commonBind.html',
                controller: UserReportCtrl
    			}).
    	when('/getUserReport',{
                    templateUrl: 'pages/commonBind.html',
                    controller: FinalUserReportCtrl
        			}).
        when('/reportHome',{
                    templateUrl: 'pages/report.html',
                    
            			}).
        //// END of USERS ///////////////////    
        
            
       ///// CPU Mapping /////////////////////     
            
        when('/cpu', {
            	templateUrl: 'pages/cpu.html',
            	}).
        when ('/cpuDetails',{
        	templateUrl: 'pages/commonBind.html',
        	controller: CpuDetailCtrl
        }).
        when ('/cpuAdd',{
        	templateUrl: 'pages/cpuAdd.html',
        	
        }).
        when('/cpuUpdateHome',{
           	templateUrl: 'pages/commonBind.html',
            controller: CpuUpdateHomeCtrl
            }).	
        when('/getCpuByID',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetCpuByIDCtrl
                }). 
        when('/cpuUpdate',{
                templateUrl: 'pages/commonBind.html',
                controller: CpuUpdateCtrl
        		}).
        when ('/cpuStores',{
              	  templateUrl: 'pages/commonBind.html',
              	  controller: CpuStoreCtrl
               }).
        when ('/cpuDesktop',{
            	  templateUrl: 'pages/commonBind.html',
            	  controller: CpuDesktopCtrl
              }).
        
        when ('/cpuOut',{
              	  templateUrl: 'pages/commonBind.html',
              	  controller: CpuOutCtrl
                }).
            	
       //// END of CPU /////////////////////////     	
      
        		
      //// Start of Monitor mapping ////////   		
        		
       when('/monitors', {
          	templateUrl: 'pages/monitors.html',
          	}).
       when ('/monitorAll',{
          	  templateUrl: 'pages/commonBind.html',
          	  controller: MonitorAllCtrl
           }).
           
       when ('/monitorAdd',{
           	  templateUrl: 'pages/monitorAdd.html',
           	  
            }). 
       when('/getMonitorByID',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetMonitorByIDCtrl
                }). 
        
        when ('/monitorStores',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorStoreCtrl
         }).
        when ('/monitorDesktop',{
      	  templateUrl: 'pages/commonBind.html',
      	  controller: MonitorDesktopCtrl
        }).
        when ('/monitorFaulty',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorFaultyCtrl
          }).
        when ('/monitorOut',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: MonitorOutCtrl
          }).
       
        when('/monitorUpdateHome',{
             	templateUrl: 'pages/commonBind.html',
                 controller: MonitorUpdateHomeCtrl
              }).
              
        when('/monitorUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: MonitorUpdateCtrl
      			}).
       
     //// END of monitor Mapping //// 	
      			
     //// Start of phone mapping ////
        when('/phones', {
      	       templateUrl: 'pages/phones.html',
      	    }).
        when ('/phoneAll',{
          	  templateUrl: 'pages/commonBind.html',
          	  controller: PhoneAllCtrl
           }).
           
        when ('/phoneAdd',{
           	  templateUrl: 'pages/phoneAdd.html',
           	  
            }). 
        
        when('/getPhoneByID',{  
                templateUrl: 'pages/commonBind.html',
                controller: GetPhoneByIDCtrl
                }). 
        
        when ('/phoneStores',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneStoreCtrl
         }).
        when ('/phoneDesktop',{
      	  templateUrl: 'pages/commonBind.html',
      	  controller: PhoneDesktopCtrl
        }).
        when ('/phoneFaulty',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneFaultyCtrl
          }).
        when ('/phoneOut',{
        	  templateUrl: 'pages/commonBind.html',
        	  controller: PhoneOutCtrl
          }).
       
        when('/phoneUpdateHome',{
             	templateUrl: 'pages/commonBind.html',
                 controller: PhoneUpdateHomeCtrl
              }).
              
        when('/phoneUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: PhoneUpdateCtrl
      			}). 
      	    
      	    
      	    
     //// End of phone mapping //// 	    
      	    
     /// Start of laptop Mapping ////
       when('/laptop', {
           	templateUrl: 'pages/laptops.html',
           	}). 
       when ('/laptopAll',{
            	templateUrl: 'pages/commonBind.html',
            	controller: LaptopAllCtrl
            }).
       when('/laptopAdd', {
               	templateUrl: 'pages/laptopAdd.html',
               	}). 
       when ('/laptopOnCall',{
            	templateUrl: 'pages/commonBind.html',
            	controller:   LaptopOnCallCtrl
            }).
       when ('/laptopStores',{
            	templateUrl: 'pages/commonBind.html',
            	controller:   LaptopStoresCtrl
            }).
       when('/laptopUpdateHome',{
             	 templateUrl: 'pages/commonBind.html',
                 controller: LaptopUpdateHomeCtrl
              }).
              
       when('/laptopUpdate',{
                  templateUrl: 'pages/commonBind.html',
                  controller: LaptopUpdateCtrl
      			}).
       when('/getLaptopByID',{  
                    templateUrl: 'pages/commonBind.html',
                    controller: GetLaptopByIDCtrl
                    }).   
                  	
        
            	
    //// End of laptop mapping /////       	
           	
        when('/phones', {
          	templateUrl: 'pages/phones.html',
            }).
        when('/loginFail',{
        	templateUrl: 'pages/loginRedirect.html'
        }).
       
            
        when('/logout', {
        	templateUrl: 'pages/commonBind.html',
            controller: LogoutCtrl
           }) ;

    }]);
    
/*app.run(['$location', function AppRun($location) {
    debugger; // -->> here i debug the $location object to see what angular see's as URL
}]);*/

